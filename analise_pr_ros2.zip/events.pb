p
26.2.0.119303$7e0918cb-32f0-47d7-a9d9-b40ffd8878be"
SQ Upgrade8��գ�3B$c2704a09-0587-4207-bf0d-d4494e33f6b9u
Use "Sonar way" (cxx)$7d45580c-9f6b-4e2d-84e2-21c2ff6e78cb"Profile8����3B$300c41cc-83c4-4f54-a221-6d7f9b9e8507�
Failed$7d45580c-9f6b-4e2d-84e2-21c2ff6e78cb"Alert*?Coverage on New Code < 80, Duplicated Lines (%) on New Code > 38����3B$a42d288f-6e54-4c2e-af43-5e790374f419l
not provided$7d45580c-9f6b-4e2d-84e2-21c2ff6e78cb"Version8����3B$82195a9d-5d7b-459c-9c11-6d3e159166d2